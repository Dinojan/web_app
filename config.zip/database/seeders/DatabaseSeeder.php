<?php
// database/seeders/DatabaseSeeder.php
class DatabaseSeeder {
    public function run() {
        // Example seeding
        $db = db();
        // $db->query("INSERT INTO users ...");
        echo "Database seeded!
";
    }
}
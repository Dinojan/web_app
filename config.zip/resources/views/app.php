<!DOCTYPE html>
<html lang="en" dir="ltr">
    @include('layouts.head')
<body>
    <main class="db-main">
        @yield('content')
    </main>
     @include('layouts.script')
</body>
</html>

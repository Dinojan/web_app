<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'DEMO APP' }}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        header { background: #f4f4f4; padding: 10px; margin-bottom: 20px; }
        main { max-width: 800px; }
    </style>
</head>